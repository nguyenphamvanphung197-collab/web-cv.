# CV website — Võ Thị Quỳnh Hương

Website CV tĩnh, responsive, dùng HTML/CSS/JS thuần. Có thể triển khai miễn phí bằng GitHub + Netlify.

## 1. Chỉnh thông tin trước khi công khai
- Xác nhận GPA 3.6/4.0 là GPA hiện tại hay GPA tốt nghiệp. Website đang ghi chú `GPA 3.6/4.0*` để tránh gây hiểu nhầm.
- Chỉ thêm thành tích, chứng chỉ, hoạt động CLB, dự án hoặc kinh nghiệm nếu bạn thực sự có. Không nên ghi thành tích bịa trong CV ứng tuyển.
- Nếu có năm học, ngày tốt nghiệp dự kiến, link LinkedIn, dự án hoặc hoạt động thực tế, hãy bổ sung vào `index.html`.

## 2. Đưa website lên GitHub
1. Đăng nhập https://github.com và chọn **New repository**.
2. Đặt tên repo, ví dụ `quynh-huong-cv`; chọn **Public** (hoặc Private nếu bạn biết cách cấp quyền cho Netlify).
3. Upload 4 file trong thư mục này: `index.html`, `style.css`, `script.js`, `README.md` lên thư mục gốc repo.
4. Chọn **Commit changes**.

## 3. Deploy bằng Netlify
1. Đăng nhập https://www.netlify.com/ bằng GitHub.
2. Chọn **Add new site → Import an existing project**.
3. Chọn **GitHub**, cấp quyền truy cập repo `quynh-huong-cv`.
4. Build settings: để trống **Build command** và nhập `.` ở **Publish directory** (hoặc để mặc định thư mục gốc nếu giao diện cho phép).
5. Chọn **Deploy**. Netlify sẽ tạo link dạng `ten-site.netlify.app`.
6. Trong **Site configuration → Change site name**, đổi thành tên ngắn còn trống, ví dụ `quynh-huong-profile`.

## 4. Cập nhật CV
Mỗi lần sửa `index.html` hoặc `style.css` rồi commit lên GitHub, Netlify sẽ tự động deploy phiên bản mới.

## Lưu ý bảo mật
Website là công khai nếu bạn bật public. Bạn đang hiển thị email và số điện thoại; chỉ giữ số điện thoại nếu bạn đồng ý để nhà tuyển dụng và người truy cập nhìn thấy.
